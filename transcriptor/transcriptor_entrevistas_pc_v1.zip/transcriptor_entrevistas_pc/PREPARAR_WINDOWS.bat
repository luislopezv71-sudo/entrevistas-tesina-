@echo off
setlocal
cd /d "%~dp0"
py -3 -m venv .venv
if errorlevel 1 (
  echo No se pudo crear el entorno. Instala Python 3 desde python.org y marca Add Python to PATH.
  pause
  exit /b 1
)
"%~dp0.venv\Scripts\python.exe" -m pip install -r "%~dp0requirements.txt"
if errorlevel 1 (
  echo No se pudieron instalar las dependencias. Comprueba internet y Python.
  pause
  exit /b 1
)
"%~dp0.venv\Scripts\python.exe" "%~dp0preparar_modelo.py"
if errorlevel 1 (
  echo No se pudo preparar el modelo.
  pause
  exit /b 1
)
echo Preparacion terminada. Ya puedes usar INICIAR_WINDOWS.bat sin internet.
pause
