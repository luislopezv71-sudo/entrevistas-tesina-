@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0.venv\Scripts\python.exe" (
  echo Falta la instalacion inicial. Ejecuta PREPARAR_WINDOWS.bat con internet.
  pause
  exit /b 1
)
"%~dp0.venv\Scripts\python.exe" "%~dp0app.py"
if errorlevel 1 (
  echo No se pudo iniciar la aplicacion. Revisa el error mostrado.
  pause
)
