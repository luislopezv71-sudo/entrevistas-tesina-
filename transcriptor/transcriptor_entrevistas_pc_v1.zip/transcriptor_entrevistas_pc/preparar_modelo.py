"""One-time online download. The transcription application never downloads a model."""
from pathlib import Path
from faster_whisper.utils import download_model

location = Path(__file__).resolve().parent / 'modelos' / 'small'
if (location / 'model.bin').is_file():
    print('Modelo ya preparado en:', location)
else:
    print('Descargando el modelo multilingüe small a:', location)
    download_model('small', output_dir=str(location))
    if not (location / 'model.bin').is_file():
        raise SystemExit('Descarga incompleta: no se encontró model.bin')
    print('Modelo listo. Puedes transcribir sin conexión a internet.')
