"""Local batch transcription of one interview. Standard library until run() loads the model."""
from __future__ import annotations

import csv
import json
import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Callable

AUDIO_EXT = {'.wav', '.m4a', '.mp4', '.webm', '.ogg', '.mp3'}
PATTERN = re.compile(r'^(?P<prefix>.+?)_(?:seg_)?(?P<number>\d{3,4})$', re.IGNORECASE)


@dataclass(frozen=True)
class Selection:
    files: tuple[Path, ...]
    prefix: str
    missing: tuple[int, ...]
    alternatives: tuple[str, ...]


def parse_audio_name(path: Path) -> tuple[str, int]:
    match = PATTERN.fullmatch(path.stem)
    if match:
        return match['prefix'], int(match['number'])
    suffix = '_v1_COMPLETO'
    if path.stem.upper().endswith(suffix.upper()):
        return path.stem[:-len(suffix)], 1
    raise ValueError(f'Nombre sin número final de bloque: {path.name}. Usa _001, _seg_001 o _v1_COMPLETO.')


def select_audio(folder: Path, prefer_wav: bool = False) -> Selection:
    if not folder.is_dir():
        raise ValueError('Selecciona una carpeta que contenga los bloques de UNA entrevista.')
    candidates = sorted((p for p in folder.iterdir() if p.is_file() and p.suffix.lower() in AUDIO_EXT),
                        key=lambda p: p.name.casefold())
    if not candidates:
        raise ValueError('La carpeta no contiene archivos WAV, M4A, MP4, WebM, OGG ni MP3.')
    complete = [p for p in candidates if p.stem.upper().endswith('_V1_COMPLETO')]
    if complete and len(candidates) > 1:
        raise ValueError('El audio completo V1 debe estar solo en su carpeta, sin bloques ni copias.')
    groups: dict[str, dict[int, list[Path]]] = {}
    labels: dict[str, str] = {}
    for path in candidates:
        label, number = parse_audio_name(path)
        key = label.casefold()
        labels.setdefault(key, label)
        groups.setdefault(key, {}).setdefault(number, []).append(path)
    if len(groups) != 1:
        raise ValueError('La carpeta mezcla entrevistas. Pon los bloques de cada entrevista en una carpeta distinta: '
                         + ', '.join(labels.values()))
    key = next(iter(groups))
    numbers = groups[key]
    if min(numbers) != 1:
        missing = tuple(range(1, min(numbers)))
    else:
        missing = ()
    missing += tuple(i for i in range(min(numbers), max(numbers) + 1) if i not in numbers)
    chosen: list[Path] = []
    alternatives: list[str] = []
    for number, paths in sorted(numbers.items()):
        extensions = [p.suffix.lower() for p in paths]
        if len(set(extensions)) != len(extensions):
            raise ValueError(f'Hay dos archivos con el mismo formato y bloque {number:03}: revisa la carpeta.')
        ranked = sorted(paths, key=lambda p: (p.suffix.lower() != '.wav') if prefer_wav else
                        (p.suffix.lower() == '.wav', p.name.casefold()))
        chosen.append(ranked[0])
        if len(ranked) > 1:
            alternatives.append(f'Bloque {number:03}: {ranked[0].name} elegido; alternativas: '
                                + ', '.join(p.name for p in ranked[1:]))
    return Selection(tuple(chosen), labels[key], missing, tuple(alternatives))


def block_number(path: Path) -> int:
    return parse_audio_name(path)[1]


def clock(seconds: float) -> str:
    millis = max(0, round(seconds * 1000))
    return f'{millis // 3600000:02}:{millis // 60000 % 60:02}:{millis // 1000 % 60:02}'


def srt_clock(seconds: float) -> str:
    millis = max(0, round(seconds * 1000))
    return f'{millis // 3600000:02}:{millis // 60000 % 60:02}:{millis // 1000 % 60:02},{millis % 1000:03}'


def output_directory(parent: Path, prefix: str) -> Path:
    parent.mkdir(parents=True, exist_ok=True)
    safe = re.sub(r'[^\w-]+', '_', prefix, flags=re.UNICODE).strip('_')[:48] or 'entrevista'
    base = f'transcripcion_{safe}_{datetime.now():%Y%m%d_%H%M%S}'
    for suffix in range(100):
        path = parent / (base if suffix == 0 else f'{base}_{suffix:02}')
        try:
            path.mkdir()
            return path
        except FileExistsError:
            continue
    raise FileExistsError('No hay un nombre libre para los resultados.')


def load_local_model(model_dir: Path):
    if not (model_dir / 'model.bin').is_file():
        raise FileNotFoundError(f'Falta el modelo local: {model_dir}. Ejecuta PREPARAR_WINDOWS.bat con internet.')
    try:
        from faster_whisper import WhisperModel
    except ImportError as exc:
        raise RuntimeError('Falta faster-whisper. Ejecuta PREPARAR_WINDOWS.bat antes de transcribir.') from exc
    return WhisperModel(str(model_dir), device='cpu', compute_type='int8', local_files_only=True)


def transcribe_with_model(model, path: Path, language: str = 'es') -> tuple[list[dict], float]:
    pieces, info = model.transcribe(str(path), language=language, beam_size=5, vad_filter=True)
    rows = [{'start': round(float(p.start), 3), 'end': round(float(p.end), 3),
             'speaker': 'Sin identificar', 'text': p.text.strip()}
            for p in pieces if p.text.strip()]
    duration = float(info.duration or 0)
    return rows, max(duration, max((r['end'] for r in rows), default=0.0))


def run(selection: Selection, parent: Path, model_dir: Path, *, allow_missing: bool = False,
        reporter: Callable[[str], None] = print,
        transcriber: Callable[[Path], tuple[list[dict], float]] | None = None,
        cancelled: Callable[[], bool] = lambda: False) -> Path:
    if selection.missing and not allow_missing:
        raise ValueError('Faltan bloques: ' + ', '.join(f'{n:03}' for n in selection.missing))
    if not selection.files:
        raise ValueError('No hay bloques para transcribir.')
    if transcriber is None:
        reporter('Cargando el modelo local. La transcripción no necesita conexión.')
        model = load_local_model(model_dir)
        transcriber = lambda path: transcribe_with_model(model, path)
    if cancelled():
        raise RuntimeError('Operación cancelada antes de crear resultados.')
    dest = output_directory(parent, selection.prefix)
    all_rows: list[dict] = []
    block_reports: list[dict] = []
    offset = 0.0
    reporter(f'Resultados: {dest}')
    for index, audio in enumerate(selection.files, 1):
        if cancelled():
            raise RuntimeError(f'Cancelado antes del bloque {block_number(audio):03}. Resultados parciales en {dest}')
        number = block_number(audio)
        reporter(f'[{index}/{len(selection.files)}] Transcribiendo bloque {number:03}: {audio.name}')
        try:
            rows, duration = transcriber(audio)
            if not isinstance(rows, list) or any(not isinstance(r, dict) or
                    not isinstance(r.get('text'), str) or
                    not isinstance(r.get('start'), (int, float)) or
                    not isinstance(r.get('end'), (int, float)) for r in rows):
                raise ValueError('Respuesta de transcripción inválida')
            duration = max(float(duration), max((float(r['end']) for r in rows), default=0.0))
            if duration < 0:
                raise ValueError('Duración inválida')
            payload = {'format': 'tesina-offline-v1', 'audioFile': audio.name,
                       'audioSize': audio.stat().st_size, 'blockIndex': number, 'segments': rows}
            (dest / f'{audio.stem}.json').write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
            for row in rows:
                all_rows.append({'block': number, 'file': audio.name,
                                 'start': offset + row['start'], 'end': offset + row['end'],
                                 'speaker': row.get('speaker') or 'Sin identificar', 'text': row['text']})
            block_reports.append({'block': number, 'file': audio.name, 'durationSeconds': duration,
                                  'startApproxSeconds': offset, 'segments': len(rows)})
            offset += duration
            reporter(f'Bloque {number:03} terminado: {len(rows)} fragmentos.')
        except Exception as exc:
            raise RuntimeError(f'Error en {audio.name}: {exc}. Resultados parciales en {dest}') from exc
    lines = [f'Entrevista: {selection.prefix}',
             'Tiempos globales aproximados: se acumula la duración de cada archivo; los intervalos entre bloques no están incluidos.',
             'Los hablantes no se identifican automáticamente.', '']
    for block in block_reports:
        lines.append(f"BLOQUE {block['block']:03} · {block['file']} · inicia cerca de {clock(block['startApproxSeconds'])}")
        for row in (r for r in all_rows if r['block'] == block['block']):
            lines.append(f"{clock(row['start'])}–{clock(row['end'])} [{row['speaker']}] {row['text']}")
        lines.append('')
    (dest / 'transcripcion_completa.txt').write_text('\n'.join(lines) + '\n', encoding='utf-8-sig')
    with (dest / 'transcripcion_completa.csv').open('w', newline='', encoding='utf-8-sig') as f:
        writer = csv.writer(f)
        writer.writerow(['Bloque', 'Archivo', 'Inicio aproximado', 'Fin aproximado', 'Hablante', 'Texto'])
        for row in all_rows:
            writer.writerow([row['block'], row['file'], clock(row['start']), clock(row['end']),
                             row['speaker'], row['text']])
    with (dest / 'transcripcion_completa.srt').open('w', encoding='utf-8') as f:
        for i, row in enumerate(all_rows, 1):
            f.write(f"{i}\n{srt_clock(row['start'])} --> {srt_clock(row['end'])}\n{row['text']}\n\n")
    report = {'format': 'tesina-desktop-v1', 'interview': selection.prefix,
              'missingBlocks': list(selection.missing), 'blockCount': len(selection.files),
              'blocks': block_reports}
    (dest / 'resumen.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    reporter(f'Listo: {len(selection.files)} bloques, {len(all_rows)} fragmentos. Revisa el texto contra el audio.')
    return dest
