"""Windows desktop UI for transcribing downloaded interview blocks locally."""
from __future__ import annotations

import os
import queue
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, scrolledtext, ttk

from core import run, select_audio

BASE = Path(__file__).resolve().parent
MODEL = BASE / 'modelos' / 'small'


class InterviewApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('Transcriptor de entrevistas · PC')
        self.geometry('790x660')
        self.minsize(620, 530)
        self.folder = tk.StringVar()
        self.dest = tk.StringVar()
        self.prefer_wav = tk.BooleanVar(value=False)
        self.allow_missing = tk.BooleanVar(value=False)
        self.messages = queue.Queue()
        self.running = False
        self.cancel_event = threading.Event()
        self.result = None
        self.selection = None
        self.build()
        self.protocol('WM_DELETE_WINDOW', self.close)
        self.after(120, self.poll)

    def build(self):
        outer = ttk.Frame(self, padding=18)
        outer.pack(fill='both', expand=True)
        ttk.Label(outer, text='Transcribir bloques descargados', font=('Segoe UI', 17, 'bold')).pack(anchor='w')
        ttk.Label(outer, text='Una carpeta por entrevista. Los audios se procesan en esta computadora.',
                  wraplength=680).pack(anchor='w', pady=(2, 14))
        for title, variable, handler in [('Carpeta de audios', self.folder, self.pick_folder),
                                         ('Carpeta donde guardar resultados', self.dest, self.pick_dest)]:
            ttk.Label(outer, text=title).pack(anchor='w')
            line = ttk.Frame(outer)
            line.pack(fill='x', pady=(2, 11))
            ttk.Entry(line, textvariable=variable).pack(side='left', fill='x', expand=True)
            ttk.Button(line, text='Elegir…', command=handler).pack(side='left', padx=(8, 0))
        options = ttk.Frame(outer)
        options.pack(fill='x', pady=(0, 8))
        ttk.Checkbutton(options, text='Preferir WAV si también está el original', variable=self.prefer_wav,
                        command=self.inspect).pack(anchor='w')
        ttk.Checkbutton(options, text='Continuar aunque falten números de bloque', variable=self.allow_missing,
                        command=self.inspect).pack(anchor='w')
        ttk.Label(outer, text='Modelo offline: ' + str(MODEL), wraplength=735).pack(anchor='w', pady=(3, 8))
        ttk.Label(outer, text='Antes del primer uso ejecuta PREPARAR_WINDOWS.bat con internet. '
                              'Después puedes desconectar la computadora.', wraplength=720).pack(anchor='w')
        self.summary = tk.StringVar(value='Selecciona una carpeta para revisar los bloques.')
        ttk.Label(outer, textvariable=self.summary, wraplength=730,
                  foreground='#1b4861').pack(fill='x', pady=(12, 8))
        actions = ttk.Frame(outer)
        actions.pack(fill='x', pady=(0, 8))
        ttk.Button(actions, text='Revisar bloques', command=self.inspect).pack(side='left')
        self.start_button = ttk.Button(actions, text='Transcribir entrevista', command=self.start)
        self.start_button.pack(side='left', padx=6)
        self.cancel_button = ttk.Button(actions, text='Detener tras el bloque actual', command=self.cancel,
                                        state='disabled')
        self.cancel_button.pack(side='left')
        self.open_button = ttk.Button(actions, text='Abrir resultados', command=self.open_result, state='disabled')
        self.open_button.pack(side='right')
        self.log = scrolledtext.ScrolledText(outer, wrap='word', height=12, state='disabled')
        self.log.pack(fill='both', expand=True)
        ttk.Label(outer, text='TXT, CSV y SRT consolidados; JSON por bloque. Los tiempos entre bloques son aproximados. '
                              'Revisa las citas escuchando el audio original.', wraplength=730).pack(anchor='w', pady=(9, 0))

    def append(self, text):
        self.log.configure(state='normal')
        self.log.insert('end', text + '\n')
        self.log.see('end')
        self.log.configure(state='disabled')

    def pick_folder(self):
        path = filedialog.askdirectory(title='Elige los audios de UNA entrevista')
        if path:
            self.folder.set(path)
            if not self.dest.get():
                self.dest.set(str(Path(path).parent / 'resultados_entrevistas'))
            self.inspect()

    def pick_dest(self):
        path = filedialog.askdirectory(title='Dónde crear una carpeta nueva de resultados')
        if path:
            self.dest.set(path)

    def inspect(self):
        if self.running or not self.folder.get():
            return
        try:
            self.selection = select_audio(Path(self.folder.get()), self.prefer_wav.get())
            parts = [f'{len(self.selection.files)} bloques de {self.selection.prefix}.']
            if self.selection.missing:
                parts.append('Faltan: ' + ', '.join(f'{n:03}' for n in self.selection.missing) + '.')
            if self.selection.alternatives:
                parts.append('Hay archivos alternativos del mismo bloque; se transcribirá uno por número.')
            self.summary.set(' '.join(parts))
            self.append(self.summary.get())
            for p in self.selection.files:
                self.append(f'  {p.name}')
            for line in self.selection.alternatives:
                self.append('  ' + line)
        except (ValueError, OSError) as exc:
            self.selection = None
            self.summary.set('Revisa la carpeta: ' + str(exc))
            self.append(self.summary.get())

    def start(self):
        if self.running:
            return
        self.inspect()
        if not self.selection:
            return
        if self.selection.missing and not self.allow_missing.get():
            messagebox.showwarning('Bloques faltantes', 'Faltan bloques. Descárgalos o marca la opción para continuar.')
            return
        if not self.dest.get():
            messagebox.showwarning('Carpeta de resultados', 'Elige dónde guardar los resultados.')
            return
        if not (MODEL / 'model.bin').is_file():
            messagebox.showerror('Modelo no preparado', 'Ejecuta PREPARAR_WINDOWS.bat con internet antes de transcribir.')
            return
        self.running = True
        self.cancel_event.clear()
        self.start_button.configure(state='disabled')
        self.cancel_button.configure(state='normal')
        self.open_button.configure(state='disabled')
        selection = self.selection
        destination = Path(self.dest.get())

        def worker():
            try:
                path = run(selection, destination, MODEL, allow_missing=self.allow_missing.get(),
                           reporter=lambda msg: self.messages.put(('log', msg)),
                           cancelled=self.cancel_event.is_set)
                self.messages.put(('done', path))
            except Exception as exc:
                self.messages.put(('error', str(exc)))
        threading.Thread(target=worker, daemon=False).start()

    def cancel(self):
        self.cancel_event.set()
        self.cancel_button.configure(state='disabled')
        self.append('Se detendrá antes de iniciar el siguiente bloque. Espera a que termine el actual.')

    def poll(self):
        try:
            while True:
                kind, value = self.messages.get_nowait()
                if kind == 'log':
                    self.append(value)
                else:
                    self.running = False
                    self.start_button.configure(state='normal')
                    self.cancel_button.configure(state='disabled')
                    if kind == 'done':
                        self.result = value
                        self.open_button.configure(state='normal')
                        self.append('Resultados completos: ' + str(value))
                        messagebox.showinfo('Transcripción finalizada', 'Los resultados están listos en:\n' + str(value))
                    else:
                        self.append('ERROR: ' + value)
                        messagebox.showerror('Transcripción detenida', value)
        except queue.Empty:
            pass
        self.after(120, self.poll)

    def open_result(self):
        if self.result and self.result.is_dir():
            os.startfile(self.result)  # Windows

    def close(self):
        if self.running:
            messagebox.showinfo('Transcripción en curso',
                                'Espera a que termine el bloque actual o pulsa «Detener tras el bloque actual».')
            return
        self.destroy()


if __name__ == '__main__':
    InterviewApp().mainloop()
